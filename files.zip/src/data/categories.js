const categories = [
  { id: 'all', name: 'All Fruits' },
  { id: 'apples', name: 'Apples' },
  { id: 'bananas', name: 'Bananas' },
  { id: 'berries', name: 'Berries' },
  { id: 'citrus', name: 'Citrus' },
  { id: 'tropical', name: 'Tropical' }
];

export default categories;